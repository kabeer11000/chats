<!DOCTYPE html>
<html>
  <head>
    <title>Simple Upload</title>
    <link rel="stylesheet" href="0-dummy.css">
  </head>
  <body>
    <!-- (A) HTML UPLOAD FORM -->
    <form method="post" enctype="multipart/form-data">
      <input type="file" name="up" required>
      <input type="submit" value="Go">
    </form>

    <?php
    // (B) HANDLE FILE UPLOAD
    if (isset($_FILES["up"])) {
      $source = $_FILES["fileup"]["tmp_name"];
      $destination = $_FILES["fileup"]["name"];
      move_uploaded_file($source, $destination);
      echo "OK";
    }
    ?>
  </body>
</html>